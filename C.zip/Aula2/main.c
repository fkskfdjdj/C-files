#include <stdio.h>

int main()
{

  // tipo nome = valor;
  // char letra = 'A';
  // int numeroInt = 5;
  // float numeroFloat = 5.25;
  // double numeroDouble = 10.5;

  char letra = 'A';
  int numeroInt = 5;
  float numeroFloat = 5.25;
  double numeroDouble = 10.5;

  printf("Letra: %c (%d) \n", letra, letra);
  printf("NumeroInt: %d \n", numeroInt);
  printf("NumeroFloat: %f \n", numeroFloat);
  printf("NumeroDouble: %f \n", numeroDouble);

  return 0;
}
