#include <stdio.h>

int main()
{

  /*
  soma: +=
  subtração: -=
  multiplicação: *=
  divisão: /=
  resto: %=
  */

  int x = 5, y = 10, z = 15;

  x = x + y; // x += y;
  y += z; // y = y + z;
  
  printf("x: %d \n", x);
  printf("y: %d \n", y);
  printf("z: %d \n", z);

  return 0;
}
