#include <stdio.h>
#define PI 3.1415

int main()
{

  const int numero1 = 10;
  printf("Número 1: %d \n", numero1);
  printf("Número 2: %f \n", PI);

  return 0;
}
