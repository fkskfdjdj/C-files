#include <stdio.h>

int main()
{

  int numero;
  float numeroFloat;

  printf("Digite dois números: ");
  scanf("%d%f", &numero, &numeroFloat);
  printf("Seus números são: %d e %f \n", numero, numeroFloat);

  return 0;
}
