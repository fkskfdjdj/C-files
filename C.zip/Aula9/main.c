#include <stdio.h>

int main()
{

  int x, y = 10;

  x = 10;

  /*
  x = y++; -> x retorna 10
  x = ++y; -> x retorna 11
  */

  x++;
  y--;

  printf("x: %d \n", x);
  printf("y: %d \n", y);

  return 0;
}
