#include <stdio.h>

int main()
{

  char letra = 'a';
  int numero = 10;
  float numeroFloat = 5.25;
  double numeroDouble = 5.2543;

  printf("Char: %c \n", letra);
  printf("Char (Ascii): %d \n", letra);
  printf("Int: %d \n", numero);
  printf("Float: %f \n", numeroFloat);
  printf("Double: %f \n", numeroDouble);

  return 0;
}
