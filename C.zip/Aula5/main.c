#include <stdio.h>

int main()
{

  int x = 97;
  char char1, char2 = 'A';
  char1 = x;

  printf("char1 = %c \n", char1);

  x = char2;

  printf("x = %d \n", x);

  return 0;
}
