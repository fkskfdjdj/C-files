#include <stdio.h>

int main()
{

  /*
  int x = 10;
  printf("x: %d \n", x);
  return 0;
  */

  // define x para 10
  int x = 10;

  // imprimi o valor de x na tela
  printf("x: %d \n", x);

  // retorna 0
  return 0;
}
