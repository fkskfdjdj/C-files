#include <stdio.h>

int main()
{

  /*
  soma: +
  subtração: -
  multiplicação: *
  divisão: /
  resto: %
  */

  char char1, char2 = '0', char3 = 'A';
  int x1, x2 = 10, x3 = 12;
  float f1, f2 = 5.25, f3 = 10.5;

  char1 = char2 + char3;
  x1 = x2 + x3;
  f1 = f2 + f3;

  printf("char1 = %c (%d) \n", char1, char1);
  printf("x1 = %d \n", x1);
  printf("f1 = %f \n", f1);

  return 0;
}
